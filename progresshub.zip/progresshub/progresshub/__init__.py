__version__ = "0.1.0"
APP_NAME = "ProgressHub"